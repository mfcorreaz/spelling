<?php
require_once __DIR__ . '/includes/verificar_sesion.php';
verificar_rol(['profesor', 'admin', 'directivo']);
require_once __DIR__ . '/config/conexion.php';

$competencia_id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT nombre FROM competencias WHERE id = ?");
$stmt->execute([$competencia_id]);
$competencia = $stmt->fetch();

if (!$competencia) {
    die('El torneo que buscás no existe.');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel de control - <?= htmlspecialchars($competencia['nombre']) ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/base.css">
</head>
<body>
    <?php include __DIR__ . '/includes/partials/navbar.php'; ?>
    <div class="contenido">
        <h2>Panel de control — <?= htmlspecialchars($competencia['nombre']) ?></h2>
        <p>Acá va a estar el tablero con el cronómetro, la palabra asignada a cada alumno,
           el registro de acierto/error, y la carga del audio de cada performance.</p>
        <p><a href="ver_competencia.php?id=<?= $competencia_id ?>">← Volver al torneo</a></p>
    </div>
</body>
</html>
