<?php
require_once __DIR__ . '/includes/verificar_sesion.php';
verificar_rol(['profesor']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Profesor - Spelling Bee</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/base.css">
    <link rel="stylesheet" href="assets/css/dashboard_profesor.css">
</head>
<body>
    <div class="navbar">
        <div class="logo">🐝 Spelling Bee — Profesor</div>
        <div class="usuario-info">
            <span><?= htmlspecialchars($_SESSION['nombre'] . ' ' . $_SESSION['apellido']) ?></span>
            <a href="logout.php" class="salir">Salir</a>
        </div>
    </div>
    <div class="contenido">
        <h2>Bienvenido/a, <?= htmlspecialchars($_SESSION['nombre']) ?></h2>
        <p>Desde acá vas a poder crear competencias, inscribir a tus alumnos y cargar palabras.</p>
        <!-- Próximos módulos: mis alumnos, crear competencia, cargar palabras -->
    </div>

    <script src="assets/js/utils.js"></script>
    <script src="assets/js/dashboard_profesor.js"></script>
</body>
</html>
