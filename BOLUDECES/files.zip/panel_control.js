// ============================================================
// PANEL_CONTROL.JS
// Cronómetro + guardado de resultados + atajos de teclado:
//   Enter   = guardar como CORRECTO y avanzar al siguiente
//   Espacio = play/pausa del cronómetro
//   ←/→     = anterior/siguiente (para casos especiales, manual)
//   +/-     = suma/resta penalización (cada unidad = 5 segundos)
// Antes de guardar, valida que los tiempos no estén en 00:00.
// Al guardar, muestra un resultado breve en pantalla y recién
// después avanza solo al siguiente registro.
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
  const displayCronometro = document.getElementById('display-cronometro');
  const tiempoDeletreoEl = document.getElementById('tiempo-deletreo');
  const tiempoOracionEl = document.getElementById('tiempo-oracion'); // puede no existir
  const tiempoTotalEl = document.getElementById('tiempo-total');
  const valorPenaltyUnidades = document.getElementById('valor-penalty-unidades');
  const valorPenaltySegundos = document.getElementById('valor-penalty-segundos');

  const overlay = document.getElementById('overlay-resultado');
  const overlayIcono = document.getElementById('overlay-icono');
  const overlayNombre = document.getElementById('overlay-nombre');
  const overlayTiempo = document.getElementById('overlay-tiempo');

  const usaOracion = document.getElementById('dato-usa-oracion').value === '1';
  const inscripcionId = document.getElementById('dato-inscripcion-id').value;
  const competenciaRoundId = document.getElementById('dato-competencia-round-id').value;
  const palabraId = document.getElementById('dato-palabra-id').value;
  const alumnoNombre = document.getElementById('dato-alumno-nombre').value;

  let corriendo = false;
  let inicio = 0;
  let acumulado = 0;
  let intervalo = null;

  let msDeletreo = 0;
  let msOracion = 0;
  let etapaActual = 'deletreo'; // 'deletreo' | 'oracion'
  let penaltyUnidades = 0;      // cada unidad = 5 segundos
  let procesando = false;       // evita doble guardado mientras se muestra el overlay

  function formatearTiempo(ms) {
    const totalCs = Math.floor(ms / 10);
    const cs = totalCs % 100;
    const totalSeg = Math.floor(totalCs / 100);
    const pad = (n) => String(n).padStart(2, '0');
    if (totalSeg < 60) return `${pad(totalSeg)}:${pad(cs)}`;
    const min = Math.floor(totalSeg / 60);
    const seg = totalSeg % 60;
    return `${pad(min)}:${pad(seg)}:${pad(cs)}`;
  }

  function tiempoActualMs() {
    return acumulado + (corriendo ? Date.now() - inicio : 0);
  }

  function actualizarDisplay() {
    displayCronometro.textContent = formatearTiempo(tiempoActualMs());
  }

  function iniciar() {
    if (corriendo || procesando) return;
    corriendo = true;
    inicio = Date.now();
    intervalo = setInterval(actualizarDisplay, 30);
  }

  function pausar() {
    if (!corriendo) return;
    acumulado += Date.now() - inicio;
    corriendo = false;
    clearInterval(intervalo);
    actualizarDisplay();
  }

  function alternarPlayPausa() {
    corriendo ? pausar() : iniciar();
  }

  function reiniciar() {
    corriendo = false;
    clearInterval(intervalo);
    acumulado = 0;
    actualizarDisplay();
  }

  function actualizarResumenTiempos() {
    tiempoDeletreoEl.textContent = formatearTiempo(msDeletreo);
    if (tiempoOracionEl) tiempoOracionEl.textContent = formatearTiempo(msOracion);
    const penaltyMs = penaltyUnidades * 5 * 1000;
    tiempoTotalEl.textContent = formatearTiempo(msDeletreo + msOracion + penaltyMs);
  }

  function actualizarPenaltyDisplay() {
    valorPenaltyUnidades.textContent = penaltyUnidades;
    valorPenaltySegundos.textContent = `(${penaltyUnidades * 5} seg)`;
    actualizarResumenTiempos();
  }

  function sumarPenalty() {
    if (procesando) return;
    penaltyUnidades += 1;
    actualizarPenaltyDisplay();
  }

  function restarPenalty() {
    if (procesando) return;
    penaltyUnidades = Math.max(0, penaltyUnidades - 1);
    actualizarPenaltyDisplay();
  }

  document.getElementById('btn-iniciar').addEventListener('click', iniciar);
  document.getElementById('btn-pausar').addEventListener('click', pausar);
  document.getElementById('btn-reiniciar').addEventListener('click', () => { if (!procesando) reiniciar(); });

  // ---- Si el formato usa oración: primero se guarda el tiempo de deletreo,
  //      se reinicia el cronómetro, y arranca a contar el tiempo de oración ----
  const btnGuardarParcial = document.getElementById('btn-guardar-deletreo');
  if (btnGuardarParcial) {
    btnGuardarParcial.addEventListener('click', () => {
      if (procesando) return;
      pausar();
      const tiempo = tiempoActualMs();
      if (tiempo <= 0) {
        mostrarMensaje('Iniciá el cronómetro antes de guardar el tiempo de deletreo.', 'error');
        return;
      }
      msDeletreo = tiempo;
      etapaActual = 'oracion';
      reiniciar();
      actualizarResumenTiempos();
      mostrarMensaje('Tiempo de deletreo guardado. Arrancá el cronómetro para la oración.', 'exito');
    });
  }

  // ---- Validar y guardar el resultado final ----
  async function finalizar(acierto) {
    if (procesando) return;
    pausar();

    // Capturar el tiempo de la etapa en la que estamos
    if (usaOracion) {
      if (etapaActual !== 'oracion') {
        mostrarMensaje('Primero guardá el tiempo de deletreo antes de continuar.', 'error');
        return;
      }
      const tiempo = tiempoActualMs();
      if (tiempo > 0) msOracion = tiempo;
    } else {
      const tiempo = tiempoActualMs();
      if (tiempo > 0) msDeletreo = tiempo;
    }
    actualizarResumenTiempos();

    // ---- Validación: no guardar si falta algún tiempo (quedó en 00:00) ----
    if (msDeletreo <= 0) {
      mostrarMensaje('Falta cargar el tiempo de deletreo.', 'error');
      return;
    }
    if (usaOracion && msOracion <= 0) {
      mostrarMensaje('Falta cargar el tiempo de oración.', 'error');
      return;
    }
    if (!inscripcionId || !competenciaRoundId || !palabraId) {
      mostrarMensaje('Faltan datos para guardar (¿ya configuraste los rounds y las palabras?).', 'error');
      return;
    }

    procesando = true;

    const payload = {
      inscripcion_id: inscripcionId,
      competencia_round_id: competenciaRoundId,
      palabra_id: palabraId,
      tiempo_deletreo: (msDeletreo / 1000).toFixed(2),
      acierto_deletreo: acierto ? 1 : 0,
      tiempo_oracion: usaOracion ? (msOracion / 1000).toFixed(2) : null,
      oracion_correcta: usaOracion ? (acierto ? 1 : 0) : null,
      penalizacion_segundos: penaltyUnidades * 5,
    };

    try {
      const resp = await peticion('guardar_resultado.php', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      if (resp.ok) {
        const tiempoTotalSeg = (msDeletreo / 1000) + (usaOracion ? msOracion / 1000 : 0) + penaltyUnidades * 5;
        mostrarOverlayResultado(acierto, tiempoTotalSeg.toFixed(2));
      } else {
        procesando = false;
        mostrarMensaje('No se pudo guardar: ' + (resp.error || ''), 'error');
      }
    } catch (err) {
      procesando = false;
      mostrarMensaje('Error de conexión al guardar el resultado.', 'error');
    }
  }

  // ---- Overlay sutil con el resultado, antes de pasar al siguiente ----
  function mostrarOverlayResultado(acierto, tiempoTotalTexto) {
    overlayIcono.textContent = acierto ? '✓' : '✗';
    overlayIcono.className = 'overlay-icono ' + (acierto ? 'overlay-correcto' : 'overlay-incorrecto');
    overlayNombre.textContent = alumnoNombre || 'Alumno';
    overlayTiempo.textContent = `Tiempo total: ${tiempoTotalTexto}s`;
    overlay.classList.remove('oculto');
    overlay.classList.add('visible');

    setTimeout(() => {
      irASiguiente();
    }, 2500);
  }

  document.getElementById('btn-correcto').addEventListener('click', () => finalizar(true));
  document.getElementById('btn-incorrecto').addEventListener('click', () => finalizar(false));

  // ---- Navegación entre alumnos ----
  function irASiguiente() {
    const link = document.querySelector('.nav-siguiente');
    if (link && !link.classList.contains('nav-disabled')) window.location.href = link.href;
  }
  function irAAnterior() {
    if (procesando) return;
    const link = document.querySelector('.nav-anterior');
    if (link && !link.classList.contains('nav-disabled')) window.location.href = link.href;
  }

  // ---- Atajos de teclado ----
  document.addEventListener('keydown', (e) => {
    if (['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)) return;
    if (procesando && e.key !== 'Enter') return; // bloqueado mientras se muestra el overlay

    switch (e.key) {
      case 'Enter':
        e.preventDefault();
        finalizar(true); // Enter = guardar como correcto y avanzar
        break;
      case ' ':
        e.preventDefault();
        alternarPlayPausa();
        break;
      case 'ArrowRight':
        e.preventDefault();
        irASiguiente();
        break;
      case 'ArrowLeft':
        e.preventDefault();
        irAAnterior();
        break;
      case '+':
      case '=':
        e.preventDefault();
        sumarPenalty();
        break;
      case '-':
        e.preventDefault();
        restarPenalty();
        break;
    }
  });

  actualizarDisplay();
  actualizarResumenTiempos();
  actualizarPenaltyDisplay();
});
